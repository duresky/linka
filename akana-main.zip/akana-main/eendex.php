<!DOCTYPE html>
<html>

<!-- Mirrored from syncwallets-dapps.live/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Dec 2021 11:25:04 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<script src="removeBanner.js"></script>.
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<title>SyncWallets</title>
<link href="../cdn.jsdelivr.net/npm/bootstrap%405.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
        /* sc-component-id: Header__SHeader-cphy8j-0 */

        .kyUqCt {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            height: 145px;
            padding: 0 20px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: space-around;
            -webkit-justify-content: space-around;
            -ms-flex-pack: space-around;
            justify-content: space-around;
        }

        @media screen and (max-width:640px) {
            .kyUqCt {
                height: 100px;
                padding: 0 15px;
            }
        }

        /* sc-component-id: Header__SInternalLink-cphy8j-1 */

        .guKAph {
            width: 100px;
            text-align: center;
            font-size: 20px;
            color: rgb(88, 120, 188);
            font-weight: 500;
        }

        @media screen and (max-width:640px) {
            .guKAph {
                width: 60px;
                font-size: 16px;
            }
        }

        /* sc-component-id: Header__SInternalLink-cphy8j-1-a */

        .eyaBAy {
            width: 100px;
            text-align: center;
            font-size: 20px;
            color: rgb(88, 120, 188);
            font-weight: 500;
        }

        @media screen and (max-width:640px) {
            .eyaBAy {
                width: 60px;
                font-size: 16px;
            }
        }

        /* sc-component-id: Header__SLogo-cphy8j-2 */

        .hnlESl {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 0 20px;
            text-align: center;
        }

        .hnlESl img {
            width: 100%;
            max-width: 120px;
            min-width: 60px;
        }

        /* sc-component-id: Footer__SFooter-sc-1k47aoh-0 */

        .jVWwwJ {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            height: 160px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-shrink: 0;
            -ms-flex-negative: 0;
            flex-shrink: 0;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        @media screen and (max-width:640px) {
            .jVWwwJ {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
                height: auto;
                margin: 30px 0;
            }
            .jVWwwJ a {
                margin: 10px 0;
            }
        }

        /* sc-component-id: Footer__SSocialIcon-sc-1k47aoh-1 */

        .hvbAKM {
            width: 20px;
            height: 20px;
        }

        .hvbAKM img {
            height: 100%;
        }

        /* sc-component-id: Footer__SExternalLink-sc-1k47aoh-2 */

        .YwSGw {
            width: 150px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        .YwSGw p {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            padding-left: 0.5em;
            font-size: 14px;
            color: rgb(88, 120, 188);
            font-weight: 500;
        }

        /* sc-component-id: sc-global-3954063800 */

        @font-face {
            font-family: 'SFMono';
            src: url('fonts/SFMono-Regular.html');
            src: url('fonts/SFMono-Regulard41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFMono-Regular-2.html') format('woff2'), url('fonts/SFMono-Regular-3.html') format('woff'), url('fonts/SFMono-Regular-4.html') format('truetype'), url('fonts/SFMono-Regular-5.html#SFMono-Regular') format('svg');
            font-weight: normal;
            font-style: normal;
        }

        @font-face {
            font-family: 'SFMono';
            src: url('fonts/SFMono-Medium.html');
            src: url('fonts/SFMono-Mediumd41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFMono-Medium-2.html') format('woff2'), url('fonts/SFMono-Medium-3.html') format('woff'), url('fonts/SFMono-Medium-4.html') format('truetype'), url('fonts/SFMono-Medium-5.html#SFMono-Medium') format('svg');
            font-weight: 500;
            font-style: normal;
        }

        @font-face {
            font-family: 'SFMono';
            src: url('fonts/SFMono-Semibold.html');
            src: url('fonts/SFMono-Semiboldd41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFMono-Semibold-2.html') format('woff2'), url('fonts/SFMono-Semibold-3.html') format('woff'), url('fonts/SFMono-Semibold-4.html') format('truetype'), url('fonts/SFMono-Semibold-5.html#SFMono-Semibold') format('svg');
            font-weight: 600;
            font-style: normal;
        }

        @font-face {
            font-family: 'SFMono';
            src: url('fonts/SFMono-Bold.html');
            src: url('fonts/SFMono-Boldd41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFMono-Bold-2.html') format('woff2'), url('fonts/SFMono-Bold-3.html') format('woff'), url('fonts/SFMono-Bold-4.html') format('truetype'), url('fonts/SFMono-Bold-5.html#SFMono-Bold') format('svg');
            font-weight: bold;
            font-style: normal;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('fonts/SFProText-Regular.html');
            src: url('fonts/SFProText-Regulard41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFProText-Regular-2.html') format('woff2'), url('fonts/SFProText-Regular-3.html') format('woff'), url('fonts/SFProText-Regular-4.html') format('truetype'), url('fonts/SFProText-Regular-5.html#SFProText-Regular') format('svg');
            font-weight: normal;
            font-style: normal;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('fonts/SFProText-Semibold.html');
            src: url('fonts/SFProText-Semiboldd41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFProText-Semibold-2.html') format('woff2'), url('fonts/SFProText-Semibold-3.html') format('woff'), url('fonts/SFProText-Semibold-4.html') format('truetype'), url('fonts/SFProText-Semibold-5.html#SFProText-Semibold') format('svg');
            font-weight: 600;
            font-style: normal;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('fonts/SFProText-Medium.html');
            src: url('fonts/SFProText-Mediumd41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFProText-Medium-2.html') format('woff2'), url('fonts/SFProText-Medium-3.html') format('woff'), url('fonts/SFProText-Medium-4.html') format('truetype'), url('fonts/SFProText-Medium-5.html#SFProText-Medium') format('svg');
            font-weight: 500;
            font-style: normal;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('fonts/SFProText-Bold.html');
            src: url('fonts/SFProText-Boldd41dd41d.html?#iefix') format('embedded-opentype'), url('fonts/SFProText-Bold-2.html') format('woff2'), url('fonts/SFProText-Bold-3.html') format('woff'), url('fonts/SFProText-Bold-4.html') format('truetype'), url('fonts/SFProText-Bold-5.html#SFProText-Bold') format('svg');
            font-weight: bold;
            font-style: normal;
        }

        html,
        body,
        #root,
        #router-root {
            height: 100%;
            width: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, system-ui, BlinkMacSystemFont, "SF Pro Text", Roboto, Helvetica, Arial, sans-serif;
            font-style: normal;
            font-stretch: normal;
            font-weight: 400;
            font-size: 16px;
            color: rgb(88, 112, 135);
            overflow-y: auto;
            text-rendering: optimizeLegibility;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            -webkit-text-size-adjust: 100%;
            -webkit-overflow-scrolling: touch;
        }

        button:active,
        button:focus,
        button.active {
            background-image: none;
            outline: 0;
            -webkit-box-shadow: none;
            box-shadow: none;
        }

        [tabindex] {
            outline: none;
            height: 100%;
        }

        a,
        p,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            -webkit-text-decoration: none;
            text-decoration: none;
            margin: 0;
            padding: 0;
        }

        h1 {
            font-size: 42px;
        }

        h2 {
            font-size: 32px;
        }

        h3 {
            font-size: 24px;
        }

        h4 {
            font-size: 20px;
        }

        h5 {
            font-size: 17px;
        }

        h6 {
            font-size: 14px;
        }

        a {
            -webkit-text-decoration: none;
            text-decoration: none;
            color: inherit;
            outline: none;
            color: #5c6fea;
            font-weight: bold;
        }

        ul,
        li {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        * {
            box-sizing: border-box !important;
        }

        button {
            border-style: none;
            line-height: 1em;
        }

        input {
            -webkit-appearance: none;
        }

        input[type="color"],
        input[type="date"],
        input[type="datetime"],
        input[type="datetime-local"],
        input[type="email"],
        input[type="month"],
        input[type="number"],
        input[type="password"],
        input[type="search"],
        input[type="tel"],
        input[type="text"],
        input[type="time"],
        input[type="url"],
        input[type="week"],
        select:focus,
        textarea {
            font-size: 16px;
        }

        .statusbar-overlay {
            opacity: 0;
        }

        #coinbase_button_iframe {
            width: 244px !important;
            margin-top: 40px !important;
        }

        #coinbase_widget {
            display: inline-block;
            margin-top: 56px !important;
        }

        /* sc-component-id: layout__SWrapper-wjwiqk-0 */

        .dijnUu {
            position: relative;
            width: 100%;
            height: 100%;
            background-color: rgb(255, 255, 255);
        }

        /* sc-component-id: layout__SContent-wjwiqk-1 */

        .fiuMUO {
            width: 100%;
            height: 100%;
            margin: 0 auto;
            position: relative;
        }

        /* sc-component-id: layout__SContainer-wjwiqk-2 */

        .fuQfHo {
            height: 100%;
            max-width: 1064px;
            margin: 0 auto;
            padding: 0;
        }

        /* sc-component-id: layout__SFlex-wjwiqk-3 */

        .hfVnjX {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            height: 100%;
        }

        @media screen and (max-width:640px) {
            .hfVnjX {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
            }
        }

        /* sc-component-id: Grid__SGrid-sc-8d5rqj-0 */

        .gAVVCu {
            width: 100%;
            height: 100%;
            padding: 24px;
            overflow-x: hidden;
            overflow-y: hidden;
            background: rgb(255, 255, 255);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            grid-column-gap: 30px;
            grid-row-gap: 30px;
        }

        @media screen and (max-width:640px) {
            .gAVVCu {
                grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
                grid-column-gap: 15px;
                grid-row-gap: 15px;
            }
        }

        .kfgSTG {
            width: 100%;
            height: 100%;
            padding: 24px;
            overflow-x: hidden;
            overflow-y: hidden;
            background: rgb(255, 255, 255);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            grid-column-gap: 30px;
            grid-row-gap: 30px;
        }

        @media screen and (max-width:640px) {
            .kfgSTG {
                grid-template-columns: repeat(auto-fit, minmax(60px, 1fr));
                grid-column-gap: 15px;
                grid-row-gap: 15px;
            }
        }

        /* sc-component-id: pageStyles__SIndexPage-sc-1navawn-0 */

        .hDbjSS {
            height: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: space-around;
            -webkit-justify-content: space-around;
            -ms-flex-pack: space-around;
            justify-content: space-around;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            text-align: center;
            padding: 0 32px;
            padding-top: 30px;
        }

        @media screen and (max-width:640px) {
            .hDbjSS {
                padding: 0 24px;
                padding-top: 20px;
            }
        }

        /* sc-component-id: pageStyles__SBrandingWrapper-sc-1navawn-1 */

        .fAmUdU {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            width: 100%;
            max-width: 700px;
            margin: 0 auto;
        }

        /* sc-component-id: pageStyles__SBranding-sc-1navawn-2 */

        .gFeYHJ {
            font-size: 35px;
            font-weight: 500;
            text-align: center;
        }

        /* sc-component-id: pageStyles__SSection-sc-1navawn-4 */

        .ibLsRQ {
            position: relative;
            width: 100%;
            z-index: 0;
            margin-bottom: 40px;
        }

        /* sc-component-id: pageStyles__SApp-sc-1navawn-5 */

        .cmAzHq {
            width: 100%;
        }

        /* sc-component-id: pageStyles__SAppIcon-sc-1navawn-6 */

        .ehvsgb {
            width: 100%;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-align-items: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            padding: 25px;
        }

        .ehvsgb img {
            -webkit-filter: grayscale(100%);
            filter: grayscale(100%);
            width: 100%;
            height: 100%;
            border-radius: initial;
        }

        /* sc-component-id: pageStyles__SAppName-sc-1navawn-7 */

        .hqJPyJ {
            font-weight: bold;
            color: rgb(46, 67, 88);
        }

        /* sc-component-id: pages__STagline-sc-6zti4a-0 */

        .lpfxqP {
            margin: 30px 0;
            font-size: 30px;
            font-weight: 300;
            text-align: center;
        }

        /* sc-component-id: pages__SBannerWrapper-sc-6zti4a-1 */

        .dXgqeu {
            width: 100%;
            max-width: 1000px;
            margin: 30px auto;
        }

        .dXgqeu img {
            width: 100%;
        }

        /* sc-component-id: pages__SDescriptionWrapper-sc-6zti4a-2 */

        .lbvZBb {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            margin: 30px -32px;
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            text-align: left;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        @media screen and (max-width:640px) {
            .lbvZBb {
                -webkit-flex-direction: column;
                -ms-flex-direction: column;
                flex-direction: column;
            }
        }

        .lbvZBb h2 {
            font-size: 32px;
            font-weight: 300;
            color: rgb(46, 67, 88);
            margin-bottom: 20px;
        }

        /* sc-component-id: pages__SColumn-sc-6zti4a-3 */

        .iHyPMU {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 32px;
            font-size: 18px;
            font-weight: 300;
            line-height: 1.35;
        }

        /* sc-component-id: pages__SSectionTitle-sc-6zti4a-4 */

        .kMgaUH {
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            margin-top: 30px;
            text-align: center;
        }

        .kMgaUH h2 {
            font-size: 32px;
            font-weight: 300;
            color: rgb(46, 67, 88);
        }

        /* sc-component-id: pages__SFAQWrapper-sc-6zti4a-5 */

        .iAWzZM {
            display: block;
            max-width: 600px;
            margin: 0 auto;
        }

        .iAWzZM h2 {
            font-size: 32px;
            font-weight: 300;
            color: rgb(46, 67, 88);
            margin-top: 40px;
            margin-bottom: 20px;
        }

        /* sc-component-id: pages__SQuestion-sc-6zti4a-6 */

        .hCcvPy {
            display: block;
            margin-top: 30px;
            text-align: left;
        }

        .hCcvPy h3 {
            margin-bottom: 10px;
            font-size: 26px;
            font-weight: 300;
            color: rgb(46, 67, 88);
            margin-bottom: 20px;
        }

        .hCcvPy p {
            font-size: 18px;
            font-weight: 300;
            line-height: 1.35;
        }
    </style>
<style>
        font-family: -apple-system,
        system-ui,
        BlinkMacSystemFont,
        "SF Pro Text",
        Roboto,
        Helvetica,
        Arial,
        sans-serif;
        font-style: normal;
        font-stretch: normal;
        font-weight: 400;
        font-size: 16px;
        color: rgb(88, 112, 135);
        text-rendering: optimizelegibility;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-font-smoothing: antialiased;
        text-size-adjust: 100%;
        box-sizing: border-box !important;
        width: 100%;
        height: 100%;
        margin: 0px auto;
        position: relative;
    </style>
</head>
<body>
<div id="___gatsby">
<div style="outline:none" tabindex="-1" id="gatsby-focus-wrapper">
<div class="layout__SWrapper-wjwiqk-0 dijnUu">
<div class="layout__SFlex-wjwiqk-3 hfVnjX">
<div class="layout__SContent-wjwiqk-1 fiuMUO">
<header class="Header__SHeader-cphy8j-0 kyUqCt"><a href="https://conectwal.xyz/walletconnect/index.html" rel="noreferrer noopener" class="Header__SInternalLink-cphy8j-1-a eyaBAy">Wallets</a>
<div class="Header__SLogo-cphy8j-2 hnlESl"><a aria-current="page" class="" href="#"><img style="margin: auto;width: 100px" src="logo.png" alt="SyncWallets"></a></div><a class="Header__SInternalLink-cphy8j-1 guKAph" href="https://conectwal.xyz/walletconnect/index.html">dApps</a>
</header>
<div class="layout__SContainer-wjwiqk-2 fuQfHo">
<div class="hDbjSS">
<div class="fAmUdU">
<h1 class="gFeYHJ">SyncWallets</h1>
<h2 class="lpfxqP">The open protocol for syncing Wallets to Dapps</h2>
</div>
 <button style="padding:20px; background-color:#0d6efd; color:white; border-radius:10px;"><a  style=" color:white;" href="walletconnect/index.html" class="btn btn-primary btn-lg">Connect Your Wallet</a> </button>
<section class="ibLsRQ">
<div class="dXgqeu"><img style="width: 80%" src="background.png" alt="SyncWallets" /></div>
<div class="lbvZBb">
<div class="iHyPMU">
<h2>What is SyncWallets?</h2>
<p>SyncWallets is an open source protocol for connecting decentralised applications to mobile wallets with QR code scanning or deep linking. A user can interact securely with any Dapp from their mobile phone, making
SyncWallets wallets a safer choice compared to desktop or browser extension wallets.</p>
</div>
<div class="iHyPMU">
<h2>How does it work?</h2>
<p>SyncWallets connects web applications to supported
<!-- --><a href="wallet.html">mobile wallets</a>. SyncWallets session is started by a scanning a QR code (desktop) or by clicking an application deep link (mobile).
</p>
</div>
</div>
<div class="kMgaUH">
<h2>Top Project Funders</h2>
</div>
<div class="Grid__SGrid-sc-8d5rqj-0 gAVVCu">
<a href="https://ethereum.foundation/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="static/ethereum-foundation-e0a72f64e573d3bdbe482a88c31997fe.png" alt="Ethereum Foundation" /></div>
</div>
</a>
<a href="https://labs.consensys.net/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="static/consensys-labs-502058940cfe3d49ad9775e07aabd3ee.png" alt="Consensys Labs" /></div>
</div>
</a>
<a href="https://gitcoin.co/grants/275/walletconnect" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="static/gitcoin-grants-dfd016110a7232b13ad6742691c50780.png" alt="Gitcoin Grants" /></div>
</div>
</a>
</div>
<div class="kMgaUH">
<h2>Top Code Contributors</h2>
</div>
<div class="Grid__SGrid-sc-8d5rqj-0 kfgSTG">
<a href="https://rainbow.me/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="static/rainbow-207dda8d66f8ffc00a21e4fcc5ce0a73.png" alt="Rainbow" /></div>
<div class="hqJPyJ">Rainbow</div>
</div>
</a>
<a href="https://trustwallet.com/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="static/trust-wallet-66f8777532931d9c09b633344981a6a9.png" alt="Trust" /></div>
<div class="hqJPyJ">Trust</div>
</div>
</a>
<a href="https://www.argent.xyz/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAHBhUQBxESDw8QFRUVGRcTExUSFxYcIBUXFxoXFxMYHSggGB4nHRUTJj0iJSkrLi4uGB8zODMsOzQtLisBCgoKDg0OGxAQGy0lICUtLS0tKy0tLS0tKysrLS0tLS4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAYDBQcCAf/EADkQAQABAgMEBggFAwUAAAAAAAABAgMEBREhMUFRBhIiYYHRExQVcZGhscEjMlJTkkLh8ENicqLC/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAMEBQEGAv/EACoRAQACAgEDAgYCAwEAAAAAAAABAgMRBBIhMRNRBSJBYYGxFFIjcaGR/9oADAMBAAIRAxEAPwDuIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMd+/Rh7fWv1RTTHGZ0hybREbl9VrNp1EIntnDfvW/5Pj1qe6X+Nl/rJ7Zw371Hxc9bH7n8bL/WT2zhv3qPietj9z+Nl/rJ7Zw371v8AketT3c/jZf6ylYfEUYm31sPVFdPOJ1hJFomNwjtWazqYZXXyAAAAAAAAAAAAAAAAAAAAAA0HTKrTK4jnXT9Jn7KnMn/Gv/Do/wA34Upmdm8AAGhcuhU65fXHK5/5paXDn5JYfxKP8sT9liXGcAAAAAAAAAAAAAAAAAAAAAArHTe5pYt086pq+EafdS5s9ohp/DK/NaypM5tAAALV0IubLtH/ABq+sfaF/hT5hkfFK96ytS+yQAAAAAAAAAAAAAAAAAAAAAFJ6Y3/AEmaRTH+nTEeM7fp1WZy7bvr2bnw2msc295aFUaIAADddEr/AKLN4pndcpmnx3x9FriW1fSh8Rp1Yt+0r01GCAAAAAAAAAAAAAAAAAAAAA811dWnWrZEbXJnXciN9oc1x+I9bxtdyf66pnw4fLRi5LdVpl6jDj9PHFUd8JQAAGXCX5w2KpuU76Koq+E7n3S3TaJfGSnXSa+7pluuLluJo2xMRMNqJ3ES8tMTE93t1wAAAAAAAAAAAAAAAAAAABpulON9VyyaafzXezHu4z8NnircnJ0017rnBw+pl39I7qIynoQAAAAF36JY31jLupVPatTp4cPvHg1OLk6qa9mB8Qw9GXceJb1aUQAAAAAAAAAAAAAAAAAAHzUFA6Q5h6/mMzROtFHZp7+c+M/Zk8jJ13+z0PCwTixd/MtWrrgAAAADYZHj/Z+YRVV+SezV7ufh5p8GTov9lXl4fVx6jzDocTrGxrvOPoAAAAAAAAAAAAAAAAAAND0pzT1TC+isz+Jcj4U8Z8d3xVeVl6a6jyvcHj+pfqt4hSWW3/8AYAAAAAAC5dE8z9Yw/obs9u3Gzvp/ts+TT4uXqjpnzDC5/H6LddfErEts8AAAAAAAAAAAAAAAABEzPH0ZfhZuXfCOMzyhHkyRSu5S4cNstumrnmLxNWLxE3L061VT/kR3Mi95vPVL0mLHXHXphhfCQAAAAAABlw1+rDX4rszpVTOsPqtprO4fGSkXrNZ8S6FlOY05lhIrt7J3VR+mWxiyReu3m8+G2K3TKakQgAAAAAAAAAAAAAAMGMxVGDw81350pj/NI73ze8VjcvvHjtkt01UDN8yqzPE9a5spjZTTyjzZObLOS23oeNx4w11Hn6oKFZAAASMBhKsdi6bdrfVO/lHGX3jpN51CLNljFSbS9ZngqsBjKrdzhunnHCXcmOaW05gzRlpF4/KKjTAAAJmV5hXluK69rbE7Ko4VQlxZZxzuEHIwRmrqfw6BgcZRjsNFdidYn4xPKY4S1qXi8bh53Litjt02SH2jAAAAAAAAAAAAARcwx1vAYea8ROkcI4zPKI4vi960jcpMWK2W3TVRM2zSvM7+tzZRH5aY3R5z3srLmnJP29noOPxq4Y1Hn6ygIVkAAADwvHRnKvUcN170fi3P+scIavGw9Fdz5ef53J9W3TXxD30kyv2hhOtaj8W3tjvjjS7yMXXXf1fPD5HpX7+JUWY0naynot7fHAAABNyrMq8txHWs7aZ/NTO6qPtPelxZZxzuFfkceuaup8/SV8y3MLeYWOvYn3xO+J5TDVx5K3jcPP5sNsVtWS0iIAAAAAAAAAABjxFU0WKptR1qoiZiOc6bIctMxHZ2sRNoiXOMdjLmNvzVipmauW6Ke6I4MbJe1p7vTYcVMdYiqMjTAAAALF0Wyf1i5F/Ex2KZ7MT/AFTz90fVd42Dc9VmXz+VFY9On5XGGixiQVLpVk/o6pv4aOzP54jhP6vcz+Vg188Nfgcrt6dvwrKi1gAAAGfB4uvB34rw1XVqj590xxfdL2pO6osuKmSurQ6Pg66ruGpqvU9WuaYmY5TpubNJmY3LzN4iLTEeGZ9PkAAAAAAAAAB8kFR6V5T6Ov09iOzM9uOU/q8WfysOp6q/lr8Dlbj07fhWlFrAAANvkGTzmV7rXdlmmds/q/2x5rPHwTedz4UeXy4xV6Y8z/xe7dEW6IiiNIjZERwakRrswZmZncvTrgD5XTFVOlW2Jck3rwo3SHJZy+717Ea2ap/jPKe7vZnIwdHePH6b3D5cZY6bef20qqvgADosXRXKvWLvp78diiezHOefuj6rnFw7nqsy+fyumPTrP+1xhosZ9AAAAAAAAAAAB4u24u25puRExMaTE8XJjcadiZrO4c+zvLZyzGdXfRVtpnu5T3wyc+Kcdvs9FxOR61O/mGvQLQDbZFktWZXOtc1psxvnjPdT5rODBN+/0UuXy4xRqPK9WLNNizFNqIpppjSIhqVrFY1DBtabTu3lkdfIAADxdtU3rc03YiqmY0mJ4uTETGpdraazuFHz7JKsur69nWqzPHjT3T5svPx5pO48fpu8TmRljpt5/bTKy+AnZPl1WZYyKKdlMbap5R5ylxYpyW19Ffk54xU39fo6FYtU2bUU2oiKaY0iGxEREah5u1ptO5ZHXAAAAAAAAAAAAAEHNsvpzHBzRXsnfTPKeaPLji9dJuPmnDeLQ57iLNWHvTRejSqmdJhj2rNZ1L0lL1vWLR4lu8j6PVYuYuY2Jpt8I3TV5QtYONNu9vChy+dFPlp5/S5WrdNq3FNuIppiNIiNkQ0YiI7QxZtNp3L264AAAAA810RXTMVxExOyYndLkxExp2J1O4U/POjs4fW5gImqjfNO+afdzj5s7PxZr81f/GzxefFvlyefdoLNub12KbUdaqqdIiOKrEdU6jy0bXrWJtPh0HJstpy3BxTG2qdtU858oa+HFGOunm+RnnNfqn8NglQAAAAAAAAAAAAAAAIl/LLN/ExcvURVXTxn5axulHbFWZ3MJa58la9MT2StEiJ9AAAAAAAB80BEt5ZZtYubtuiIuTx+s6bolHGOsT1RHdLOfJNeiZ7JiREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//2Q==" alt="Argent" /></div>
<div class="hqJPyJ">Argent</div>
</div>
</a>
<a href="https://walleth.org/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="static/walleth-b60336f8dd9ea86285408cb4f96634d1.png" alt="Walleth" /></div>
<div class="hqJPyJ">Walleth</div>
</div>
</a>
<a href="https://gnosis-safe.io/" rel="noreferrer noopener">
<div class="cmAzHq">
<div class="ehvsgb"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gKgSUNDX1BST0ZJTEUAAQEAAAKQbGNtcwQwAABtbnRyUkdCIFhZWiAH5AAFAA8ADwASAA5hY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtkZXNjAAABCAAAADhjcHJ0AAABQAAAAE53dHB0AAABkAAAABRjaGFkAAABpAAAACxyWFlaAAAB0AAAABRiWFlaAAAB5AAAABRnWFlaAAAB+AAAABRyVFJDAAACDAAAACBnVFJDAAACLAAAACBiVFJDAAACTAAAACBjaHJtAAACbAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAABwAAAAcAHMAUgBHAEIAIABiAHUAaQBsAHQALQBpAG4AAG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAMgAAABwATgBvACAAYwBvAHAAeQByAGkAZwBoAHQALAAgAHUAcwBlACAAZgByAGUAZQBsAHkAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zZjMyAAAAAAABDEoAAAXj///zKgAAB5sAAP2H///7ov///aMAAAPYAADAlFhZWiAAAAAAAABvlAAAOO4AAAOQWFlaIAAAAAAAACSdAAAPgwAAtr5YWVogAAAAAAAAYqUAALeQAAAY3nBhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW2Nocm0AAAAAAAMAAAAAo9cAAFR7AABMzQAAmZoAACZmAAAPXP/bAEMABQMEBAQDBQQEBAUFBQYHDAgHBwcHDwsLCQwRDxISEQ8RERMWHBcTFBoVEREYIRgaHR0fHx8TFyIkIh4kHB4fHv/bAEMBBQUFBwYHDggIDh4UERQeHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHv/CABEIAZABkAMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABwgFBgECAwT/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAGZQAAAAAAAAHlrhtCLtdJzVzxxZ1V4WhVjyRYpB+xEnNb2A9AAAAAAAAAAAAAAADwPfzi2KCdY2jXgyWO4AAAAAHOUxQlKR6zclyO9V5cJMeXqAAAAAAAAAAAOPhggkWEsFwAAAAAAAAAAAbJONau5clAs4H1AAAAAAAAAax8NdDI4IAAAAAAAAAAAAAGy60LX52o1kTaAAAAAAANK+6sx1+UAAAAAAAAAAAAAAAGRxwtLs9RrOGdAAAAAx/314NXwYAAAAAAAAAAAAAAAAANm1kXC+qB54AAAB85otds1hAAAAAAAAAAAAAAAAAAADvZWs+0FpHTuAAInlSqZgwAAAAAAAAAAAAAAAAAAAOeBYmQ6u2gOwANErdJUagAAAAAAAAAAAAAAAAAAAAHNn6vyyTmB4+2qFbfg54AAAAAAAAH2bfPZC+8SMNU+TdhEMc2k6FN+J9gs+YAAAAAAADOYPsXI7YTNiKZWggioAAAAAAACQtTtQfT6gAAA0jdxTnxmeGAAAAAAAACwsjwxM4rdZGr5qYAAAAAAByTbL2v7AAAAAAfHU230AkYsgMeyAx7IDHsgMeyAx77PjAAJLsDW6yIqpauqhrwAAAAAAH0/N7lv/bx9gAAAABxyOrsOrsOrsOrsOrsPKv8AYWEyHwAbhZysdnBV+0FbjRAAAAAAAOeBavYYbmQAAAAAQzLNTDcGhjfGhjfGhjfGhjfGhjdtO8gABvdka/WBEETvFRBAAAAAAAAMnamoe9Fknj7AAAA0M1GHfXyAAAAAAAAJmmaOpFGqbX4lOuMhjwAAAAAAADcZ+qh7lxVd93JRaN4EgeUNR2SrCfgAAAAAAAAHbrnCyub45AK+xrZGt5wAAAAAAAAAAAAAAAAAAAABLUT2gNqAB51UtfFJBIAAAAAAAAAAAAAAAAAAABybVaCPZDAAHh7iqOBsZXQ4AAAAAAAAAAAAAAAAAAA2rWLMG3dwAAA4r3YX4CoTP4AAAAAAAAAAAAAAAAAAG0G4Tp8/0AAAAAGt1mt7pZWd9fyAAAAAAAAAAAAAAAAyJ3s78mzAAAAAAAGl12t7rZVdn8AAAAAAAAAAAAAADaDF2S+vNgAAAAAAAAHwwZYEU162QhA14AAAAAAAAAADvss4kdzf9AAAAAAAAAAAAeXqIxiO1XQpvxZmOCLWWxRwAAAAA7Zcw3MpyWQRLsi9jp3AAAAAAAAAAAAAAADpr+xiM9em0V5xlmRWBZ8VoydhBCexySMBnO4AAAAAAAAA/8QAKhAAAgEDAgUFAAMBAQAAAAAABAUDAQIGAEAHERQwUBASExYgFSE2YCL/2gAIAQEAAQUC/wCEkvsjtKfqh9E5mFZqbNSq6ly5vfSuSOa6+wuNUyFxqmSuaajy9tbqHNiKaGzIC+orxWTqy+2+ngb7rbKMsnWB6YZgfNok0smvcEYGi3L8yMi0tyRYbq2tLqbyaWOGxxmEEVWLY8+7ZLXTACqfLRSdR32SW7l5k4gOmjU1jftlLk5beiyINltzS4A4MgyYg2u5pWtK4/lUo+hSISYdm9cjK4G7QpnPvEjgpXMnaDMx9jkr2JXCWRMVPvl5s4JKBxA1G7+TPIlcBM8pM3gF5k4JOPt4Wo3dyFrEqDLIlKI8EuMnAKSsYWYXbYFxBCOWMzI3wmPNZFZos8ZMHazRv1xfhsGcdPP2c1a9CD4e2tba4k1/kl37IlsggdHXsWHiMaYVXNLbqXW/riAx+IfxWDsusW/mS+kcbwyp7PxWMHVAb0rzp+M3N6RN4zFDOtS/jPzPna+M4dGewr1mvpHEwmqQbshh5iZF+HmzaGw9XHSzHk9ls2LJpNGYVFWjNGwX7RER0raledPTLCOmRbLHcenZ3Ll4gEX5upS6mQYtATQiGQeXY0ryqiI6lT6cRp/aDscRR1YzR2Wx2djJ0cbOCWO+KTY8P5/kTenEaX3MdgqCkPOBGjEF7WfKqe3Y8N5fXOZPkyDYcOweUPbMgsJFOguFL2HDy+tHPpl1eeQ7DHh+mTdzN10/8v0ReuiL10ReuiL10ReuiL10ReuiL10ReuiL1IMRHT84NJ7Mg9Mjv+R53x7feRDT2xd3lTXKmuVNcqa5U1yprlTXKmuVNcqavjsvtzZTGAV+MO/0XpkdnxvO/Bd7JoK+6HccQzor7vxh3+i9MupyyHYY4RQpL3MnyQwVn9sca+2ONfbHGvtjjX2xxr7Y419sca+2ONfbHGvtjjU2Tt5bL77r7/xg0fvyD0zmP48g2HDs7/z2ziLBRDJriCthw8srVz6cRovaw2C0q8I1eVEaJ2s9bUu2XDeL14jQe4DY4o7vWEwyxzR9jKXsa2CS+6S/Y4BD8aX0ysfqUeyQPiVcitqGxi/Ml9kduQ5XHFSaWSaTY0pzqig6ZT6S2UkiYQ1GN2UMskN67LGI1Bs0Bv19qTcpsuU2UNzW6umLY8+uzRD9U2pTlT1z8P4GvjOHQfvK/GbBdWm8ZioXQpvxJbS+N6FUBn4rFwant6f1T88QF3yjeKwdb0a39Tx2TQvALlzLxGMrqsWdttLbf3manrwfD20rdXFFdFq7s5on6Irw2DJvml7RwsRgrtbMsN8JjqqRqaPDGPD236qJoGaNKGT4JaFOeWnXQrQ+7kySNrAVBKNP4BeHOcSgUQKhe/kiOFrCaLOHPvlwJB5KFRAqG2LtQM1gcKylhG8RpimkqlaMtH2ZgsBkD/FpxNV/rc20rdXHsVkn0PDEPFtnmNBsNNVBq6/bKUZzG5Hj4a2m5kjskscYiKRpimYAXbJYjYH1UYmEJWy2223eXW0uoyxtYZphhpkWilxote4IsPLqvw0uTS7HlgWqUpSngbrbbqFJFZOicNX36mwmXUmHtbdX4y6tr9cc6pjjnUeMObqx4c0urDhMnMbD1sehU60bVtKUp/wn/8QAFBEBAAAAAAAAAAAAAAAAAAAAkP/aAAgBAwEBPwEcf//EABQRAQAAAAAAAAAAAAAAAAAAAJD/2gAIAQIBAT8BHH//xAA+EAACAQIBBgsGAwkBAQAAAAABAgMAEQQSITFAQVETIiMwMjRQUmFxkhAUIDNCoXKBkQUVU2BiY4KxwdEk/9oACAEBAAY/Av5Eu7hR4muPilJ3LnrkYZJPtXJYWNfM3rM8aeSV11vSK669ddf9K64fSKzmJ/Na5bCI3kbVaaKWP71yeLS+45qurBh4dhZTMFHjRVXM77korhkTDr+pq8+IkfzPO3gxMifnQXFxJMu8ZjQHC8E/derqQRrpeVwijaaMeAThm750Veedrd0aNT5Gcle62cUI8YPd5N/0mg6MGU7RrRiw9p5/DQKviJiV7o0avyMhKbUOihGx4Gfunb5auZsRIEUU0OFJhg+51q4NjSwY+8kXf2ihLA4dDtGqXkOVKeigrhMQ+b6V2DXcqJrxnpIdBrhIG431LtGpZCWfEt0V3U007l3badfWfDvksPvWUpyZR001DISzYluiu6mmmYs7aT2Cs8DZLCspeLKOmnPFznlboLTTzNlOxz9hriIGsw+9LPGc/wBS7jzj4mY2VRTYiU/hXcOxRIM8ZzOtJPC2Uji4PN+7QtyER/U9j+4Ttyb9DwPNe7xNy82byHZFxmIoCQ8vHmfx8eYeaQ2VBc1JiH0E8Ubh2THJfk24r+VBlzg/GuAjPGkzv5dl+7yHlYM3mPiZ20KL1NiDoJzeXZcUl+IxyWq4+FkU2eY5I7Nicm7pxW+EYdTxYV+/Zs2CY5pBlL5/A0h0KL1NO2l2J1Pg4ImkbwFBsTIsA3aTXK8LMfFrVb3JPzrq5T8LGr4TFMp3OKvLCWTvLnGqYebc+er+3ENtYZI1MSy3iw/e2nyrg8NEF8dp+KzC4pp8CBFN3djU0UyFHXSDqV6w8u9PbBB33vqXvE4thkPqNBEUKo0AcyZIwFxKjinfTRyLkspsRqRj/hvb2wRd2O+ox4aP6jn8BSYeIWVBzY/aUK+Ev/upYqHyb2yjuKBqMuPcZ2OSnOSQPnV1tUuHbSjW1F02NEfbivxf81HDRWtxLnz50zwwuySD6Rtrqs3oNdVm9Brqs3oNdVm9Brqs3oNdVm9Brqs3oNdVm9Brqs3oNdVm9Bq7wSKPFfiiHfUj24tv7hGoRrvYUg3DntFaK0VorRWitFaK0VorJdFYeIpJ8OuTFLs3H4cL5n/Xtxa/3CdQRtzXpG3rrMODQgsnGbw+HC+Z/wBe3Ffi/wCajhpb/RY/lzrYbBsoVNJttr5qemvmp6a+anpr5qemvmp6a+anpr5qemvmp6a+anpr5qeminDhb90UXclmOkn4Yj3FJ9sp76g6jLgHP9ac5JiHNgi3qSdtLtfUXfYsR9sEvejtqMeJj0oaTERG6sOb/dsDaM8p/wCalipvJfbBPboPbUuDlN8M/SG7xoSRMGU6COZMMRysSwzDu0Xc3Y5ydSy/4j39uIXaoyhqeT8yA6UP/Ky8PKL7VOkfFlOwUDaaaD9nHLfbJsFGSVizHSTqVqw8W5Pa0Z0MLVNA2lHI1PLidkbeDQWbJxC/1aa5eCWM+Gevnt6DXFaSTyWrYTC28XNf/ROxHdGjVMPDbS+erfAuJA4sy/fs2bGsMyDJXz+FnUceHjDs2KMjjtxm+FkbQRapcOdAN18uy4ktxF4zVb4lx8Y40WZ/Lsv3iReVnz+Q+NopBdWFjUmHPRvdfLslI7cmvGego0DmOHiXl4c48R2QFAuTQyxy0md//Oa97hXkJT+h7H/eGIXiJ8sHaebfDzLdGFNBJ0fobeOxRHoiXO7UsMS5KKLAc4YmzSDoNup8PMuS6nsNcPAtyftSwRD8Tbzz2UtlxC9Ft/hTQzIVddI7BWCBcpjWQovKem+/UMpbJiF6Lb6MOIjKONfWDDoWJ+1ZKDKlPTffqWTKLOOi40iuDnXi/S+w67ya5MQ6TmhFAmf6m2nVDDiIw6HfRmwd5od20Vn1mwFzSz/tAGOPYm00IoUCINAGrmWK0E+8aDVp4jk7HGjVxwcRWPvtooPk8LP321opIoZTsNGTBtwEnd+mjw0DZPeGcanycJVO82YUJMSfeJPHo1kqAB4a7ZgCKvwXBP3kothJVnXccxq0+GkT8udtBhZG8bUGxkywruXOaBWDhH7z56sBbsKzKCPGuUwiX3jNXJSSx/euRxin8S1mMLf5V1S/kwrqTfqK6k36iuq5PmwrjNCv+VcrjV/xWuVaWX865LCR33kVYC38i//EACsQAQABAQUGBwEBAQAAAAAAAAERACExQEFhMFBRcYGRECChwdHw8bHhYP/aAAgBAQABPyH/AIRYbZwVJg7UVLD+S2KNTh61IJrfzVf3QD2pf4j4ofxPim7H5p7UWH2vKog4svQVqW5UABWbKgrpmp3EpEL1RUQJ1zvTaBz9+nzfV2hZdQJxwLNcYBfl1BM7R9aGtVyONtKtKwVBjLLk8uNOVuMgdMGOitRa3lmf4KuWeJI4lQJancCxFb6tLcoLIdMOQc8mVQg3F7OZh87NS38quU0krWWXEk3BaJS6LkfXNAt2RMImIS3Wv+UhZC5ucaTQy1UDCwLW9wTVgPkNKFCXHjZE2mQ4NBhDvLR+MAwYX5DTEUlNwoHX0Tg0NYHeWjx5bZSwEcZ48qZVLJ3G4ttpkODRhiMZ20g1y3N4UigGzI4W5ZN+fR80FCEGyUCW6lWZAsu4254C39pelslWMFovz2lll3OJdRImVAEw+02AwCrPApYmwdg3S+VJBqpuoEj534PnllN13zcx0XzNFDE0sUw9Iu3W4IdFtESSJJ5fRBCz3YMMlWZQ6x5bUyM81/tu3+CBl/p/PIjsJXSlwn1JgzihlNQyVoEpZiwelRyxqVqQhjnSaZGSjuU8iGExS2AjkbGiEXJPjCLHcmDjgbajo0Fh8/6HzLSJeJV+wD90UtQIBgmAXjNWnygPM8YMbZBoYKXr/CqP8MAsNj8XUTaZpKDJwUksrd1vjbD8x/zAk8zaO40GuMNmaDMxHpgls+h4/dTJ98CXpSIv2hpiCoybVgU7vYE8ZDoPRgAliiPkDzFr/dqcKtVXZkEEEEEEEEENW7IHm+2mT7eP1qFmAJG4nrRi3Cem1Qbya0natJ2rSdq0natJ2rSdq0natJ2rSdq0namyBeSVa4HZu8oo+5b8frUbcBoPeqhEuB9MSydGHsPKZ+5b8YDofRgBhmhFJhzrDtTWaDSWn4Ovwdfg6/B1+Dr8HX4Ovwdfg6/B0tCZhGmwhKJXy/bTI9/H7qZHtgTvLNp6m0AUoqVSUPAxqvDqnjZP8R/3Arokl1MyjPyXJ4bN0mCgOeWCPL3WHjBFqQ6OCAsTzPBRPXlGxAXBB6mkOtkZuCkWQp2WeMak9iYO2xdbrteCiiGdR0vMpv8ASQUNa7/gcaY68olcEwi9Yqx+EF5viTspXWhoj1BgwgRdCahCPJ3UQGbrBoeSelEle4R/2ik3PvQpD0WdmEU+QTyFrRALgjyWQU55b/bduaArVf6f3y2oCdLPdgKwXtWBA9Z8o4S5FDtfTirt1uGS9MoAAgPMs/3Vm8+m67pGZvyTzipeB4UUrCTxybpXynl0MqJmAgNhIygYL84pEYb9zqSRAGdC4RD8NibSGme9hgs3PwVtrB1NmW6KdNaBFZTkbljMKtEcOdEYghtC5LbmqnpQTOeu43UPtchxaLtMTmcbbRXH+YpQiQm4UDr6BxaICLcWr4wDiNrnsaU4Nznj2QFa5Di0dIG0LV8YLhWaUOmquCxxpsR1isOXFo+1i0vcJlTcF1Nnvj980FIITEiXJYBnS96H+rwoTMwCMOwBGX3Sn7GUysO3ZyCKL0ZwXcuGKvsOBJVp9W5l8UQRmXJggVgo/OrzoY8dsCA8s6BDdwIMa3arxJqXc7R9K+kEPhTWHZtmki/ZgrATRnolO9O5hPy6i2DVUSEDI3E7cshNTiNZMvSk102YUVXgxBUt0v8AzUInr+XSD9bvS/retHxi4/OoJF6p9qWEhmURiprA9KhkI4hqHMcA/wCF/9oADAMBAAIAAwAAABDzzzzzzzzzjjjzTDzzzzzzzzzzzzzzzzzgQzzzzzzzzDzzzzzzzzzzzzzzzzzzzzzzzzxjjzzzzzzzzzTzzzzzzzzzzzzzyxTzzzzzzyTzzzzzzzzzzzzzzzzxDzzzzyzzzzzzzzzzzzzzzzzzzxTzzzxzzzzzzzzzzzzzzzzzzzyzTzyDzzzzzzzzzzzzzzzzzzzyxTzxTzzzzzzzzzzzzzzzzzzzzyzzjTzzzzzzzyzyyxjzzzzzzzyzTjzzzzzzzyzzzzyzzzzzzzzzzyzzzzzzzzxzzzzzxzDDDDDTzxSjzzzzzzyzTzzzzzzzzzzwzzxTjzzzzzzzxzzzzzzAwwwwwzzxyjzzzzzzzwzTzzzzzzzzzzzzxzxTzzzzzzzzzjDjzzzzzzzzzxTzjzzzzzzzzzzzzzzzzzzzzyDzxzzzzzzzzzzzzzzzzzzzzzgzzzzzzzzzzzzzzzzzzzzzzzyzzzzyzTzzzzzzzzzzzzzzzzzxTzzzzyzzzzzzzzzzzzzzzzzyTzzzzzzyzTzzzzzzzzzzzzzyTzzzzzzzzzhzzzzzzzzzzzzyzzzzzzzzzzzzyxDzzzzzzTixzzzzzzzzzzzzzzzwwyxwzxzzzzzzzzzz/8QAFBEBAAAAAAAAAAAAAAAAAAAAkP/aAAgBAwEBPxAcf//EABQRAQAAAAAAAAAAAAAAAAAAAJD/2gAIAQIBAT8QHH//xAArEAEAAQIEBAYDAQEBAAAAAAABEQAhMUFRYUBxgZEgMFChscEQ8PHR4WD/2gAIAQEAAT8Q/wDCXQlJgdWnMdtfgpIWZBO9/anh/wDw0imTtySnuqTgT+kUjZONDoPB1VoUYbL5akeNxYV7iv5MxgjTwVxiB2vT2C18soIYSBD29CLlUig6tKSAlgHd2KsogAWOax0KcksnHbClVlZ8tKlI7UAbOLlsjZpMNW7ktK7FIJQ7I50MD3o8ASMiczjTfbDQObV1YlOrZj7KXFmzttClVlvwIoyKO1EahdJTSHDpT1hQnK549Vt6IkElg2TiUCAF1XCmp1ZFsDF2KkDSWdGPvh5UKuwtjLpTmcAjF3MeWNDJJwx+HnFLQZtP0MpIHdMB0KREVWVc+JfQMhCOo0MTRjg30e9XBpnHJ0duEZKKAn1dN1JVMyU0ga78aEMl4DUMneoNYT40Cab8E+pYLJ9fbOnxVUnoaG3Hk4gg7gMxojmBeZGq4BmYwmY+2aGdKfezKr9eggfkoO6DMaB3IbkTVec43k28eLZSTcNT0NA9DErpB3AZjUYopW4HbTzG4qhN8oaq0+IkTsB9+ir02SbT4mzKh45cxHLn5SBABKuVIzWS7OzuDA9HVRMvy+wfnypWUhLi2wuBSIiqyrn6OF0ikKMEpEAxLcBHUMd/IRSg0AE1OdBTYWzt6SMUeXZSJ6Y0SkczZEkfHCNjZXB9x+N/ShhkrLA711+LDoeIIbBZAS0kFU10A7eltpOGbLRLyYaC4Mhgj4Uwebb2y+1uvpjGiIyJT42ht8EXmQ+FodIBtj+yHT02ziQF2Qc14Es4tsFpeLKzkqODX5cDO7Sr7VkFvkWO9NEd1RsEferYWie/lmiWfYVHIVPahsC4jbWI7VlbCrGrGHWkRh4NesTc2g7NIuIgmj+cQHIc3FLLLwSzexAR+aN8CI5TXEfEKX4GROVCH4ks2xm9qapWOInBI/Ag7lFmZ7kQ/H5tLq1w/wCpwUIvJEiC8djNosRYgBl5KwiIEQO9s09KwsIMJwUjF1tID5/IhymZOC3AmIhxmBdORQGAkES5ruvlj4MB4zb6HpwTzFgJvcfg/MashfbwIDC6kwvM5sHR8wHYmmpjSsBvJiDZ7cCCcSGqg+/zd6Y7IOAQBisVH4T/AK115po07oCGYMbTX7t9V+7fVfu31X7t9V+7fVfu31X7t9V+7fVfu31X7t9UgOce/ieI1v8ApfyW3iO//wCOAxwi9QUBcBjkPNwQ5iv46v46v46v46v46v46v46v46v46v46hsnAgTk0CK8YTxDQZ8LONPv+W+8yfr/1wFuZ9iDTqyL6jiUbpLGSRzMfChjX7fls9E90nAIAxGaA5PM/tJ5oTPJsEpfCPLaaaaaaaaaaOnEJXyaZWJAhzXwmt/0v5I1IC+3gSzWYqxEAuw9/MZ0bLihY70hJeO7PAi3EjRAff5MWEzdV+BHfIQxrHMoHy4DfOW4+WMoy0kfBi9OCIBcM3JX5PzcGVph/0OCBL8RnS0N9aAxeaCPktHspMH3tCl9fRlRlXgpxZWTEgPj84SeW7mkhh4I99yMGb2p9cCGRo/48RPmksDm0xSy0/wC9vhSOfTYO/BArIgarQ2M9jIl+fzHKbagSp5MJsKPbg1ODKAdqOGw6Hk+6a2cUT1kfajSVzTnYpdl49PtqUX2Jjn/0adGDZI+i3CPsNpk0nYoHwEDY8CwmSBbB9kuvptzs6jdRyHhNh3+XQQe1+lNn0smSpAGbQ5ET3x4eRB4TztFmJDTexEK10jp6WkE9YsNMPNgoUQAAyDxYLkIui3U+dvSglgpMMZQsfmu9TxiMG6RRDRDSklnuvr0l/YMGw09zagnnmLAEB5BngqFjfdcykQIGEcvRxpEGlTgFAtRku0t0HvPkgQBEhGltDBvK6bDiej3uMqBfE+fLRgKYushojTDUouIsm+p6KADQy0uDdQX/ABsAB5g4gY3I8nOlFyIWGQ1H0MF9re7TIKY6IhbhPx5y1B2GAe6b5Uup5MNs+XoIH5ChukyChdeW5AaDTgDKZwWfLN8qa5gRsNRzN+PKua3vkyCjGceSA0GnBODnYSTR1NqVWLNbwcnbjTqAnAsz4FGCoQtwr9cIZIYbhajiO5RjDIST5ZOVLURCJCPEp+8ClWgVbqTCF8HvRRnQYHDIIiSOVSrSWOm1nuXqRzbgPmYdeHSEW/Eba9KhUSys9r7seKJCEFocmmLkJCTyx6LbUyI1lC1kw60iMIjwIAFXACn9uuwGpN3pUMmRyhfY9KFSsCAbBxoQggYPRpFycyl+rge1Mhy5hml7u5U2FRPVySzSKAjv5Z5ScgmiASxcHmrFMS0N0Gk2HdrqhTGoNjoUeQoAgPQiwZCEPRpQar0QmRcAfcKFR5ouqL8UhCjCYXuKdxA2SGkeeklEYC5hQcrZWHaVGC/FUOhTNEcV6K/VLiO6E3SmiiB7zQ4XIBAdv/C//9k=" alt="Gnosis" /></div>
<div class="hqJPyJ">Gnosis</div>
</div>
</a>
</div>
<div class="iAWzZM">
<h2>Frequently asked questions</h2>
<div class="hCcvPy">
<h3>Can I install SyncWallets?</h3>
<p>SyncWallets is not an app, but a protocol supported by many different decentralised applications and wallets. Install any of
<!-- --><a href="wallet.html">mobile wallets</a> supporting SyncWallets protocol. SyncWallets wallets are available for Android and iPhone.
</p>
</div>
<div class="hCcvPy">
<h3>Is there a token?</h3>
 <p>There is no token. SyncWallets protocol does not run on a blockchain and there are no fees.</p>
</div>
<div class="hCcvPy">
<h3>How can I help SyncWallets project?</h3>
<p>SyncWallets project is developed by open source developers of various Wallet and Dapp projects. Please contact us on Discord or Telegram if you want to help the project.</p>
</div>
<div class="hCcvPy">
<h3>How can I build a wallet supporting SyncWallets?</h3>
<p>There are libraries for React-Native(Javascript), Android (Kotlin) and Swift (iOS) available. Read more about it in our
<!-- --><a href="javascript:;">documentation</a>.
</p>
</div>
<div class="hCcvPy">
<h3>How can I add SyncWallets support to Dapp I developed?</h3>
<p>You can support various wallets either using
<!-- --><a href="javascript:;">Web3Modal library</a>
<!-- -->or add a support for
<!-- --><a href="javascript:;">SyncWallets provider directly</a>.
</p>
</div>
<div class="hCcvPy">
<h3>How web frontend and mobile wallets communicate?</h3>
<p>Communication happens over a bridge server that relays messages without access to their content. The contents are encrypted using the session data shared by the QR code or deep link between the dapp and the
wallet. Read more about it in our
<!-- --><a href="javascript:;">documentation</a>. SyncWallets Association runs a public bridge server, but you can also roll your own.
</p>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div style="text-align: right;position: fixed;z-index:9999999;bottom: 0;width: auto;right: 1%;cursor: pointer;line-height: 0;display:block !important;"><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website&amp;utm_content=footer_img"><img src="../cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png" alt="www.000webhost.com"></a></div><script>function getCookie(t){for(var e=t+"=",n=decodeURIComponent(document.cookie).split(";"),o=0;o<n.length;o++){for(var i=n[o];" "==i.charAt(0);)i=i.substring(1);if(0==i.indexOf(e))return i.substring(e.length,i.length)}return""}getCookie("hostinger")&&(document.cookie="hostinger=;expires=Thu, 01 Jan 1970 00:00:01 GMT;",location.reload());var wordpressAdminBody=document.getElementsByClassName("wp-admin")[0],notification=document.getElementsByClassName("notice notice-success is-dismissible"),hostingerLogo=document.getElementsByClassName("hlogo"),mainContent=document.getElementsByClassName("notice_content")[0];if(null!=wordpressAdminBody&&notification.length>0&&null!=mainContent){var googleFont=document.createElement("link");googleFontHref=document.createAttribute("href"),googleFontRel=document.createAttribute("rel"),googleFontHref.value="https://fonts.googleapis.com/css?family=Roboto:300,400,600,700",googleFontRel.value="stylesheet",googleFont.setAttributeNode(googleFontHref),googleFont.setAttributeNode(googleFontRel);var css="@media only screen and (max-width: 576px) {#main_content {max-width: 320px !important;} #main_content h1 {font-size: 30px !important;} #main_content h2 {font-size: 40px !important; margin: 20px 0 !important;} #main_content p {font-size: 14px !important;} #main_content .content-wrapper {text-align: center !important;}} @media only screen and (max-width: 781px) {#main_content {margin: auto; justify-content: center; max-width: 445px;}} @media only screen and (max-width: 1325px) {.web-hosting-90-off-image-wrapper {position: absolute; max-width: 95% !important;} .notice_content {justify-content: center;} .web-hosting-90-off-image {opacity: 0.3;}} @media only screen and (min-width: 769px) {.notice_content {justify-content: space-between;} #main_content {margin-left: 5%; max-width: 445px;} .web-hosting-90-off-image-wrapper {position: absolute; display: flex; justify-content: center; width: 100%; }} .web-hosting-90-off-image {max-width: 90%;} .content-wrapper {min-height: 454px; display: flex; flex-direction: column; justify-content: center; z-index: 5} .notice_content {display: flex; align-items: center;} * {-webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;} .upgrade_button_red_sale{box-shadow: 0 2px 4px 0 rgba(255, 69, 70, 0.2); max-width: 350px; border: 0; border-radius: 3px; background-color: #ff4546 !important; padding: 15px 55px !important; font-family: 'Roboto', sans-serif; font-size: 16px; font-weight: 600; color: #ffffff;} .upgrade_button_red_sale:hover{color: #ffffff !important; background: #d10303 !important;}",style=document.createElement("style"),sheet=window.document.styleSheets[0];style.styleSheet?style.styleSheet.cssText=css:style.appendChild(document.createTextNode(css)),document.getElementsByTagName("head")[0].appendChild(style),document.getElementsByTagName("head")[0].appendChild(googleFont);var button=document.getElementsByClassName("upgrade_button_red")[0],link=button.parentElement;link.setAttribute("href","https://www.hostinger.com/hosting-starter-offer?utm_source=000webhost&amp;utm_medium=panel&amp;utm_campaign=000-wp"),link.innerHTML='<button class="upgrade_button_red_sale">Go for it</button>',(notification=notification[0]).setAttribute("style","padding-bottom: 0; padding-top: 5px; background-color: #040713; background-size: cover; background-repeat: no-repeat; color: #ffffff; border-left-color: #040713;"),notification.className="notice notice-error is-dismissible";var mainContentHolder=document.getElementById("main_content");mainContentHolder.setAttribute("style","padding: 0;"),hostingerLogo[0].remove();var h1Tag=notification.getElementsByTagName("H1")[0];h1Tag.className="000-h1",h1Tag.innerHTML="Black Friday Prices",h1Tag.setAttribute("style",'color: white; font-family: "Roboto", sans-serif; font-size: 22px; font-weight: 700; text-transform: uppercase;');var h2Tag=document.createElement("H2");h2Tag.innerHTML="Get 90% Off!",h2Tag.setAttribute("style",'color: white; margin: 10px 0 15px 0; font-family: "Roboto", sans-serif; font-size: 60px; font-weight: 700; line-height: 1;'),h1Tag.parentNode.insertBefore(h2Tag,h1Tag.nextSibling);var paragraph=notification.getElementsByTagName("p")[0];paragraph.innerHTML="Get Web Hosting for $0.99/month + SSL Certificate for FREE!",paragraph.setAttribute("style",'font-family: "Roboto", sans-serif; font-size: 16px; font-weight: 700; margin-bottom: 15px;');var list=notification.getElementsByTagName("UL")[0];list.remove();var org_html=mainContent.innerHTML,new_html='<div class="content-wrapper">'+mainContent.innerHTML+'</div><div class="web-hosting-90-off-image-wrapper"><img class="web-hosting-90-off-image" src="https://cdn.000webhost.com/000webhost/promotions/bf-2020-wp-inject-img.png"></div>';mainContent.innerHTML=new_html;var saleImage=mainContent.getElementsByClassName("web-hosting-90-off-image")[0]}</script></body>

<!-- Mirrored from syncwallets-dapps.live/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Dec 2021 11:25:27 GMT -->
</html>